//! Minimal native Rust `FastRPC` capability boundary, without an inference library.
//!
//! The ordinary API performs fixed read-only CDSP capability queries. A separate
//! consuming terminal probe can allocate/register/unregister exactly 4KiB; that
//! registration may implicitly open a domain session. The separate terminal X2
//! queue diagnostic submits one fixed F32 matrix to a reviewed signed package.
//! It changes no OS trust and qualifies no model inference. Native calls need an
//! external process deadline; synchronous driver calls have no in-process timeout.
//! The trusted caller also owns the child environment and must exclude vendor
//! search-path, unsigned-process, power and runtime overrides before loading.
#![deny(unsafe_code)]
#![deny(warnings)]

use std::fmt;
use std::path::{Path, PathBuf};

mod compute;
mod hmx_projection;
mod htp_ops;
mod native_q2;
mod power;
mod projection;
mod session;
mod session_mapping;
pub use compute::{
    COMPUTE_ALLOCATION_BYTES, COMPUTE_GGML_SOURCE, COMPUTE_K, COMPUTE_M, COMPUTE_N, COMPUTE_Q2_K,
    COMPUTE_REQUEST_BYTES, COMPUTE_RESPONSE_BYTES, QueueComputeReport,
};
pub use hmx_projection::{
    HMX_Q2_ACT_WORKERS, HMX_Q2_BATCH_COMMAND_BYTES, HMX_Q2_BATCH_OPERATIONS,
    HMX_Q2_BATCH10_COMMAND_BYTES, HMX_Q2_BATCH10_OPERATIONS, HMX_Q2_HVX_WORKERS,
    HMX_Q2_MAX_RESIDENT_WEIGHT_BYTES, HMX_Q2_POWER_MODE_BURST, HMX_Q2_VTCM_REQUEST_BYTES,
    HmxQ2ProjectionLimits, HmxQ2ProjectionReport, HmxQ2Submitter, HmxQ2WeightHandle,
    HmxQ2WeightRegistry,
};
pub use htp_ops::{
    HTP_DMA32_MAX_STRIDE_BYTES, HtpOpCode, HtpOpPassFlags, htp_fastdiv, requires_dma64_stride,
    solve_binary_kparams, solve_glu_kparams, solve_unary_kparams,
};
pub use native_q2::{
    NATIVE_Q2_ARENA_ODD_WEIGHT_STEP_BYTES, NATIVE_Q2_ARENA_WEIGHT_STEP_BYTES,
    NATIVE_Q2_MAX_ARENA_WEIGHT_BYTES, NATIVE_Q2_MAX_COLUMNS, NATIVE_Q2_MAX_RESIDENT_WEIGHT_BYTES,
    NATIVE_Q2_MAX_ROWS, NATIVE_Q2_MAX_WEIGHT_ARENAS, NATIVE_Q2_MAX_WEIGHT_BYTES,
    NATIVE_Q2_MAX_WORKING_BYTES, NATIVE_Q2_VTCM_REQUEST_BYTES, NativeQ2ProjectionLimits,
    NativeQ2ProjectionReport, NativeQ2Submitter, NativeQ2ValidatedOutputs, NativeQ2WeightHandle,
    NativeQ2WeightRegistry,
};
pub use power::{PowerStatus, power_status};
pub use projection::{
    GuardedQ2Submitter, Q2_PROJECTION_MAX_OPERATIONS, Q2_PROJECTION_MAX_ROWS, Q2ProjectionLimits,
    Q2ProjectionReport,
};
pub use session::{
    GET_EFFECTIVE_DOMAIN_ID, GET_URI, MAP_FD, MAP_FD_DELAYED, SessionPreparationReport,
};
pub use session_mapping::SessionMappingReport;

#[cfg(all(windows, target_arch = "aarch64"))]
#[allow(
    unsafe_code,
    reason = "Small audited Windows SCM, loader, trust and vendor capability boundary"
)]
mod windows;

/// Exact ggml host-driver source used to verify the Windows loading convention.
pub const GGML_SOURCE: &str = "94256114c229674ef96e76eb2dea596e65b43818";
/// Exact public Qualcomm header used to pin capability fields and constants.
pub const FASTRPC_SOURCE: &str = "a56e9d4de3614a8d8f4b0e15ff561350c4b686e3";
/// Compute-DSP domain from the public Qualcomm remote header.
pub const CDSP_DOMAIN: u32 = 3;
/// `DSPRPC_GET_DSP_INFO`, used only with the handle-free control function.
pub const GET_DSP_INFO: u32 = 2;

/// Explicit rejection; no failed operation becomes a zero-valued capability.
#[derive(Debug)]
pub enum Error {
    /// The candidate supports only native Windows ARM64.
    UnsupportedPlatform,
    /// The SCM path or a filesystem ancestor failed validation.
    InvalidDriverPath,
    /// A native operation failed; stage is fixed and code is unmodified.
    Native(&'static str, i64),
    /// Ordinary file access failed before driver loading.
    File(std::io::Error),
    /// Model-free ABI or decoding checks failed.
    Contract,
    /// The diagnostic child inherited an unsupported vendor/runtime override.
    InheritedOverride,
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnsupportedPlatform => f.write_str("native-windows-arm64-required"),
            Self::InvalidDriverPath => f.write_str("invalid-system-driver-path"),
            Self::Native(stage, code) => write!(f, "{stage}:{code}"),
            Self::File(_) => f.write_str("system-driver-file-access-failed"),
            Self::Contract => f.write_str("native-rpc-contract-failed"),
            Self::InheritedOverride => f.write_str("inherited-native-runtime-override"),
        }
    }
}

impl std::error::Error for Error {}

/// Fixed query attributes. No arbitrary driver control value is exposed.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u32)]
pub enum Capability {
    /// Whether the domain is supported.
    Domain = 0,
    /// Reported number of 64-byte HVX contexts.
    Hvx64 = 2,
    /// Reported number of 128-byte HVX contexts.
    Hvx128 = 3,
    /// Driver-reported VTCM page size; not an allocation guarantee.
    VtcmPage = 4,
    /// Driver-reported VTCM page count; not concurrent free capacity.
    VtcmCount = 5,
    /// Architecture encoding, retained raw and decoded separately.
    Architecture = 6,
    /// HMX depth capability; not measured matrix throughput.
    HmxDepth = 7,
    /// HMX spatial capability; not measured matrix throughput.
    HmxSpatial = 8,
}

impl Capability {
    /// Fixed vendor attribute ID; there is no caller-supplied control value.
    #[must_use]
    pub const fn id(self) -> u32 {
        match self {
            Self::Domain => 0,
            Self::Hvx64 => 2,
            Self::Hvx128 => 3,
            Self::VtcmPage => 4,
            Self::VtcmCount => 5,
            Self::Architecture => 6,
            Self::HmxDepth => 7,
            Self::HmxSpatial => 8,
        }
    }

    /// Stable receipt label.
    #[must_use]
    pub const fn name(self) -> &'static str {
        match self {
            Self::Domain => "domain-support",
            Self::Hvx64 => "hvx-64b",
            Self::Hvx128 => "hvx-128b",
            Self::VtcmPage => "vtcm-page",
            Self::VtcmCount => "vtcm-count",
            Self::Architecture => "architecture",
            Self::HmxDepth => "hmx-depth",
            Self::HmxSpatial => "hmx-spatial",
        }
    }
}

/// Complete bounded attribute inventory, excluding unsigned-process controls.
pub const CAPABILITIES: [Capability; 8] = [
    Capability::Domain,
    Capability::Hvx64,
    Capability::Hvx128,
    Capability::VtcmPage,
    Capability::VtcmCount,
    Capability::Architecture,
    Capability::HmxDepth,
    Capability::HmxSpatial,
];

/// Exact C `remote_dsp_capability` layout from the pinned Qualcomm header.
#[repr(C)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CapabilityRequest {
    /// CDSP domain ID.
    pub domain: u32,
    /// One fixed attribute selector.
    pub attribute_id: u32,
    /// Driver output, meaningful only when the native result is zero.
    pub capability: u32,
}

/// Results of exactly one terminal 4KiB registration probe.
///
/// This observes allocation/host access/mapping APIs only, never DSP compute or
/// DMA. A poisoned result pins uncertain resources until supervised process death.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[expect(
    clippy::struct_excessive_bools,
    reason = "The diagnostic receipt must retain each independent completed or failed native step"
)]
pub struct MappingProbeReport {
    /// Fixed terminal stage; no provider text or memory address is included.
    pub stage: &'static str,
    /// Requested host scratch extent, always 4096 bytes.
    pub bytes: u32,
    /// The native allocator returned a nonnull pointer.
    pub allocation_succeeded: bool,
    /// A nonnegative descriptor was obtained from that allocation.
    pub descriptor_observed: bool,
    /// Exact negative descriptor result when descriptor lookup failed.
    pub descriptor_error: Option<i32>,
    /// CPU bytes were written/read before any registration attempt.
    pub cpu_roundtrip_verified: bool,
    /// Whether the explicit registration API was invoked.
    pub mapping_attempted: bool,
    /// Exact mapping return code; absent means the call was not attempted.
    pub mapping_result: Option<i32>,
    /// Exact unmapping return code; absent means the call was not attempted.
    pub unmapping_result: Option<i32>,
    /// The normal native free call returned after no mapping or a successful unmap.
    pub free_completed: bool,
    /// Uncertain native buffer, library and file lifetimes remain pinned.
    pub poisoned: bool,
    /// The driver DLL and file guard remain pinned after any mapping attempt.
    pub owner_pinned_until_exit: bool,
}

impl MappingProbeReport {
    const fn new() -> Self {
        Self {
            stage: "not-started",
            bytes: 4096,
            allocation_succeeded: false,
            descriptor_observed: false,
            descriptor_error: None,
            cpu_roundtrip_verified: false,
            mapping_attempted: false,
            mapping_result: None,
            unmapping_result: None,
            free_completed: false,
            poisoned: false,
            owner_pinned_until_exit: false,
        }
    }

    /// Whether allocation, host check, mapping, unmapping and normal free completed.
    #[must_use]
    pub const fn completed_mapping_cycle(self) -> bool {
        self.allocation_succeeded
            && self.descriptor_observed
            && self.cpu_roundtrip_verified
            && self.mapping_attempted
            && matches!(self.mapping_result, Some(0))
            && matches!(self.unmapping_result, Some(0))
            && self.free_completed
            && !self.poisoned
    }
}

/// Decode the architecture's packed decimal low byte as in the pinned host.
///
/// Invalid decimal nibbles and zero remain unknown. The raw driver value must
/// also be retained; this supplies no device, kernel or performance eligibility.
#[must_use]
pub const fn decode_architecture(raw: u32) -> Option<u32> {
    let major = (raw & 0xff) >> 4;
    let minor = raw & 0x0f;
    if major > 9 || minor > 9 || major == 0 {
        None
    } else {
        Some(major * 10 + minor)
    }
}

/// Model-free checks that run without opening services, files or DLLs.
///
/// # Errors
/// Returns a fixed contract error if ABI size/alignment/offsets or architecture
/// decoding differ from the pinned C contract.
pub fn self_check() -> Result<(), Error> {
    if size_of::<CapabilityRequest>() != 12
        || align_of::<CapabilityRequest>() != 4
        || std::mem::offset_of!(CapabilityRequest, domain) != 0
        || std::mem::offset_of!(CapabilityRequest, attribute_id) != 4
        || std::mem::offset_of!(CapabilityRequest, capability) != 8
        || decode_architecture(0x81) != Some(81)
        || decode_architecture(0x73) != Some(73)
        || decode_architecture(0).is_some()
        || decode_architecture(0x8a).is_some()
        || MappingProbeReport::new().completed_mapping_cycle()
        || !session::self_check()
        || !compute::self_check()
    {
        return Err(Error::Contract);
    }
    Ok(())
}

/// Validated service-derived path; creating it does not load any driver code.
#[derive(Debug)]
pub struct DriverLocation(PathBuf);

impl DriverLocation {
    /// Read the fixed `qcnspmcdm` service and validate its `DriverStore` location.
    ///
    /// # Errors
    /// Rejects nonnative platforms, missing SCM access, malformed paths and
    /// reparse ancestors. No environment variable or caller path chooses a DLL.
    #[cfg_attr(
        not(all(windows, target_arch = "aarch64")),
        allow(
            clippy::missing_const_for_fn,
            reason = "Only the unsupported-target stub is constant; the shared native API performs runtime driver operations"
        )
    )]
    pub fn inspect_system() -> Result<Self, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::inspect_system().map(Self)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Service-derived absolute vendor driver path, suitable for external hashing.
    #[must_use]
    pub fn path(&self) -> &Path {
        &self.0
    }
}

/// Single-threaded native capability session with retained file/library lifetime.
pub struct Driver {
    location: DriverLocation,
    #[cfg(all(windows, target_arch = "aarch64"))]
    inner: windows::Driver,
}

impl Driver {
    /// Verify local Authenticode trust and load the fixed service-derived driver.
    ///
    /// The caller must also bind this path, file digest and publisher to its
    /// reviewed driver evidence. Cached Authenticode trust is not a Microsoft
    /// publisher pin, fresh revocation check or inference qualification.
    ///
    /// # Errors
    /// Rejects native/path/file/signature/loader/export failures. Caller-owned
    /// process deadlines must cover signature validation and every native call.
    #[cfg_attr(
        not(all(windows, target_arch = "aarch64")),
        allow(
            clippy::missing_const_for_fn,
            reason = "Only the unsupported-target stub is constant; the shared native API performs runtime driver operations"
        )
    )]
    pub fn open_system() -> Result<Self, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            let location = DriverLocation::inspect_system()?;
            let inner = windows::Driver::open(location.path())?;
            Ok(Self { location, inner })
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Exact service-derived path whose signed file is retained by this session.
    #[must_use]
    pub fn path(&self) -> &Path {
        self.location.path()
    }

    /// Issue only the fixed handle-free capability control request for CDSP.
    ///
    /// # Errors
    /// Preserves native failure codes; output bytes are not used on failure.
    #[cfg_attr(
        not(all(windows, target_arch = "aarch64")),
        allow(
            clippy::missing_const_for_fn,
            reason = "Only the unsupported-target stub is constant; the shared native API performs runtime driver operations"
        )
    )]
    pub fn capability(&mut self, capability: Capability) -> Result<u32, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            self.inner.capability(capability)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, capability);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Prepare fixed default-CDSP session metadata without opening a DSP module.
    ///
    /// The architecture must be exactly v73 or v81 from the pinned signed bundle.
    /// Both vendor requests are fixed and validated; a refusal never falls back
    /// to a family-derived domain or hand-constructed URI. This does not establish
    /// signed deployment or a session and grants no buffer-mapping authority.
    ///
    /// # Errors
    /// Rejects unsupported platforms and capability/export failures. Other native
    /// refusals remain separate stages and exact codes in the returned report.
    #[cfg_attr(
        not(all(windows, target_arch = "aarch64")),
        allow(
            clippy::missing_const_for_fn,
            reason = "Only the unsupported-target stub is constant; the shared native API performs runtime driver operations"
        )
    )]
    pub fn prepare_session_metadata(&mut self) -> Result<SessionPreparationReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            self.inner.prepare_session_metadata()
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = self;
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Consume this driver in one fixed signed-module/session FD mapping diagnostic.
    ///
    /// The trusted supervisor must independently verify and retain the exact
    /// pinned package/catalog membership and driver identity before calling.
    /// `ADSP_LIBRARY_PATH` must equal `package_directory` exactly; no other vendor
    /// override is supported. Only the fixed v73/v81 module, session zero and FD=2
    /// mapping are used. No unsigned-process control or computation is requested.
    /// Progress snapshots distinguish entered from completed native operations.
    /// After a module-open attempt all driver/module/catalog owners stay pinned
    /// until supervised process exit, including after explicit handle close.
    ///
    /// # Errors
    /// Rejects malformed paths, missing exports, inherited overrides and metadata
    /// failures before opening a module. Native refusals remain exact report codes.
    /// This terminal diagnostic requires external deadlines and verified teardown.
    pub fn session_mapping_probe(
        self,
        package_directory: &Path,
        progress: impl FnMut(&SessionMappingReport),
    ) -> Result<SessionMappingReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::session_mapping_probe(self.inner, package_directory, progress)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, progress);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Run the fixed signed-package reference process initialization and FD probe.
    ///
    /// This separately selected diagnostic additionally issues the reference's
    /// `DSPRPC_CONTROL_UNSIGNED_MODULE` request with enable=1 for the validated
    /// effective default-CDSP domain before `GET_URI` and module open. This requests an
    /// unsigned DSP process class; it is not a signed-PD-only control and cannot
    /// authorize arbitrary DSP bytes. The supervisor must still independently
    /// verify and retain the pinned signed package/catalog and driver identities.
    /// It changes no OS certificate store, test-signing or boot policy. Exact
    /// closed Windows-driver implementation semantics remain vendor-dependent.
    /// There is no fallback or retry from `session_mapping_probe`; choosing this
    /// method is explicit. All owners stay pinned after the initialization attempt.
    ///
    /// # Errors
    /// Uses the same path/environment, process deadline, guarded package and
    /// verified cleanup prerequisites as `session_mapping_probe`. Native refusal
    /// remains an exact code in the terminal receipt; no weaker path follows it.
    pub fn reference_session_mapping_probe(
        self,
        package_directory: &Path,
        progress: impl FnMut(&SessionMappingReport),
    ) -> Result<SessionMappingReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_session_mapping_probe(self.inner, package_directory, progress)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, progress);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Submit one fixed F32 matrix operation to the newer signed X2 package.
    ///
    /// This consuming terminal diagnostic requires independent source-bound
    /// Windows ARM64 queue-layout/prototype and seven-argument start-wire
    /// controls, the exact reviewed v0.10.0 package/catalog/driver identities,
    /// guarded package files and an external child-process deadline/Job owner.
    /// It explicitly uses the fixed reference process initializer before open.
    /// The caller must exclude inherited vendor/runtime overrides; the sole
    /// exception is `ADSP_LIBRARY_PATH` exactly equal to `package_directory`.
    /// It changes no OS trust or boot policy. It does not accept caller tensor,
    /// opcode, pointer, power, mapping, queue or start-field overrides.
    ///
    /// All native consumers remain pinned after any uncertain call. Only a
    /// validated exact numeric response, successful stop/close/unmap allow the
    /// fixed allocation's normal free; driver/package owners remain pinned to
    /// process exit regardless. No serving admission or performance verdict
    /// follows, and vendor-session teardown still needs independent evidence.
    ///
    /// # Errors
    /// Rejects unsupported platforms/families, malformed paths, missing exports,
    /// inherited overrides or metadata failures. Native refusals and partial
    /// progress are retained as exact codes in the terminal report.
    pub fn reference_queue_compute_probe(
        self,
        package_directory: &Path,
        progress: impl FnMut(&QueueComputeReport),
    ) -> Result<QueueComputeReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_queue_compute_probe(self.inner, package_directory, progress)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, progress);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Consume this driver in one fixed guarded-Q2 K=256/M=32/N=2 integer probe.
    ///
    /// The same source-bound package, Windows ABI, signed catalog/driver,
    /// child environment, external deadline and Job prerequisites as the F32
    /// queue probe apply. All tensor bytes, solver fields and expected outputs
    /// are fixed internally. The control checks two exact integer limbs through
    /// the signed `Q2_0`/`Q8_1` quantizer with -128/+127 original code extremes,
    /// zero-weight guards, both guard signs and the fourth two-bit symbol.
    /// No original model scales, transforms, adapters or state run on the DSP.
    ///
    /// It retains every uncertain consumer through verified teardown and never
    /// grants model, full quantizer-range, performance or profile qualification.
    ///
    /// # Errors
    /// Rejects unsupported platforms/families and the same path, identity,
    /// export, environment or metadata failures as the fixed F32 queue probe.
    /// Native partial progress and refusals remain exact terminal-report data.
    pub fn reference_queue_q2_probe(
        self,
        package_directory: &Path,
        progress: impl FnMut(&QueueComputeReport),
    ) -> Result<QueueComputeReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_queue_q2_probe(self.inner, package_directory, progress)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, progress);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Run the fixed F32 control with one direct nonblocking packet write.
    ///
    /// This explicit diagnostic isolates submission through the documented
    /// six-argument `dspqueue_write_noblock` export. It preserves the F32 packet,
    /// mapping, cache flags, response, numeric and teardown contracts of
    /// [`Self::reference_queue_compute_probe`]. The timed F32/Q2 methods retain
    /// their original write path. There is no automatic fallback, no retry and
    /// no reuse of a queue after a refused or uncertain submission. A would-block
    /// return pins owners just like any other failed write. Independent hosted
    /// prototype checks and the existing external process supervision are required.
    ///
    /// # Errors
    /// Rejects the same unsupported platform, metadata, path, override or export
    /// failures as the original control. A missing nonblocking export rejects
    /// before native process initialization; no timed alternative is attempted.
    pub fn reference_queue_noblock_probe(
        self,
        package_directory: &Path,
        progress: impl FnMut(&QueueComputeReport),
    ) -> Result<QueueComputeReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_queue_noblock_probe(self.inner, package_directory, progress)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, progress);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Run the fixed guarded-Q2 control with one direct nonblocking packet write.
    ///
    /// This separately selected diagnostic preserves the exact Q2 fixture and
    /// integer-result checks of [`Self::reference_queue_q2_probe`], using the
    /// one-call submission contract of [`Self::reference_queue_noblock_probe`].
    /// It does not run an F32 control first, fall back from a timed refusal or
    /// retry a write. Every selected control requires its own source-bound
    /// supervisor and contributes to the same aggregate owner-device budget.
    ///
    /// # Errors
    /// Rejects unsupported platforms, missing exports, path/environment or
    /// metadata failures before submission. Native returns and incomplete
    /// stages retain the same conservative pinned-owner semantics.
    pub fn reference_queue_q2_noblock_probe(
        self,
        package_directory: &Path,
        progress: impl FnMut(&QueueComputeReport),
    ) -> Result<QueueComputeReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_queue_q2_noblock_probe(self.inner, package_directory, progress)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, progress);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Execute bounded caller-prepared guarded-Q2 operations in one X2 session.
    ///
    /// This experimental terminal bridge uses the same pinned signed package,
    /// driver, catalog, reference initializer, child environment, source-bound
    /// Windows ABI controls and external Job/deadline prerequisites as the fixed
    /// Q2 probe. K=256/N=2 and the audited HVX solver remain fixed; M may range
    /// from 32 to 17,408 in multiples of 32. A single bounded mapped allocation
    /// and queue are reused only after each exact correlated completion.
    ///
    /// `work` must independently verify the returned integer dots and complete
    /// its projection before returning success. Any callback error, unwinding,
    /// deadline, malformed output or native uncertainty pins every owner until
    /// supervised process exit. No partial projection, CPU replay, inference
    /// eligibility or performance claim follows from this API. The caller must
    /// publish results only after [`Q2ProjectionReport::completed_cycle`] passes.
    ///
    /// # Errors
    /// Rejects unsupported platforms, malformed inputs and the fixed probe's
    /// identity/export/path prerequisites. Partial native and callback failure
    /// remains observable in the returned report with no weaker retry.
    pub fn reference_q2_projection(
        self,
        package_directory: &Path,
        limits: Q2ProjectionLimits,
        progress: impl FnMut(&Q2ProjectionReport),
        work: impl FnOnce(&mut dyn GuardedQ2Submitter) -> Result<(), Error>,
    ) -> Result<Q2ProjectionReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_q2_projection(self.inner, package_directory, limits, progress, work)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, limits, progress, work);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Execute fixed K128/N8 integer-bitplane operations through one HMX session.
    ///
    /// Requires the same retained signed-package/catalog, source-bound ABI,
    /// driver, child-environment and external process-deadline prerequisites as
    /// [`Self::reference_q2_projection`]. The fixed session requests one HMX,
    /// one HVX worker and 64KiB VTCM; these requests establish no effective
    /// placement or granted memory. Source-derived chunks bound scratch and
    /// every output is checked before reuse. `work` must independently verify
    /// exact dots and complete its projection. Any error retains uncertain
    /// consumers until supervised exit with no retry or CPU replay.
    ///
    /// Publish results only after the HMX-marked report's completed cycle. This
    /// terminal experimental API grants no inference eligibility or speed claim.
    ///
    /// # Errors
    /// Rejects unsupported platforms and the guarded bridge's path, identity,
    /// deployment and lifetime prerequisites; native refusal remains observable.
    pub fn reference_hmx_q2_projection(
        self,
        package_directory: &Path,
        limits: HmxQ2ProjectionLimits,
        progress: impl FnMut(&HmxQ2ProjectionReport),
        work: impl FnOnce(&mut dyn HmxQ2Submitter) -> Result<(), Error>,
    ) -> Result<HmxQ2ProjectionReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_hmx_q2_projection(
                self.inner,
                package_directory,
                limits,
                progress,
                work,
            )
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, limits, progress, work);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Execute full-`K` 1-op native `HTP_TYPE_Q2_0` operations through one X2 session.
    ///
    /// Uses the same retained signed-package/catalog, source-bound ABI, driver,
    /// child-environment and external process-deadline prerequisites as
    /// [`Self::reference_q2_projection`]. The session requests 8 HVX workers,
    /// 2 MiB VTCM and burst power mode, executing a full `K <= 5120`, `M <= 17408`
    /// (`N = 1`) projection in a single DSP operation (`HTP_MM_KERNEL_HVX_QUANT_ROW_N1`).
    ///
    /// # Errors
    /// Rejects unsupported platforms and the guarded bridge's path, identity,
    /// deployment and lifetime prerequisites; native refusal remains observable.
    pub fn reference_native_q2_projection(
        self,
        package_directory: &Path,
        limits: NativeQ2ProjectionLimits,
        progress: impl FnMut(&NativeQ2ProjectionReport),
        work: impl FnOnce(&mut dyn NativeQ2Submitter) -> Result<(), Error>,
    ) -> Result<NativeQ2ProjectionReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::reference_native_q2_projection(
                self.inner,
                package_directory,
                limits,
                progress,
                work,
            )
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, limits, progress, work);
            Err(Error::UnsupportedPlatform)
        }
    }

    /// Open a persistent full-`K` 1-op native `HTP_TYPE_Q2_0` session owned by
    /// the returned [`NativeQ2Session`].
    ///
    /// # Errors
    /// Rejects unsupported platforms and invalid package, driver or mapping state.
    pub fn open_native_q2_session(
        self,
        package_directory: &Path,
        limits: NativeQ2ProjectionLimits,
    ) -> Result<NativeQ2Session, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::open_native_q2_session(self.inner, package_directory, limits)
                .map(NativeQ2Session)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = (self, package_directory, limits);
            Err(Error::UnsupportedPlatform)
        }
    }
    /// Consume this driver in one fixed 4KiB allocation/registration/unmap probe.
    ///
    /// The documented registration call may implicitly open a domain session;
    /// this opens no custom DSP module and invokes no compute. Every subsequent
    /// driver open/query in this process rejects. Any mapping/unmapping error
    /// pins the uncertain allocation until supervised process death. Every mapping
    /// attempt retains the DLL/file owner until process death because implicit
    /// domain-session teardown has not been qualified, even after a successful unmap.
    /// Do not run this terminal diagnostic inside a serving process.
    ///
    /// # Errors
    /// Rejects unsupported platforms, repeated probes and missing native exports
    /// before allocation. Per-step native refusals are retained in the report.
    pub fn scratch_mapping_probe(self) -> Result<MappingProbeReport, Error> {
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            windows::mapping_probe(self.inner)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = self;
            Err(Error::UnsupportedPlatform)
        }
    }
}

/// Owned full-`K` native `HTP_TYPE_Q2_0` session with direct resident preparation,
/// single/multi-operation projection and fused `SwiGLU` submission.
///
/// Cleans up its queue, module and `FastRPC` mapping when dropped. Submission
/// support and terminal refusal remain defined by the native session; forwarding
/// does not enable the unfinished full-FFN-chain backend.
pub struct NativeQ2Session(
    #[cfg(all(windows, target_arch = "aarch64"))] windows::NativeQ2Session,
    #[cfg(not(all(windows, target_arch = "aarch64")))] std::convert::Infallible,
);

// Keep the owned facade's complete submission contract in one implementation.
// The model-free probe below instantiates this same forwarding implementation
// with a recording submitter, including optimized overrides whose trait defaults
// deliberately use slower fallbacks or reject unsupported work.
macro_rules! impl_native_q2_session_forwarding {
    ($session:ty, $dispatch:ident) => {
        impl NativeQ2Submitter for $session {
            fn remaining_operations(&self) -> Option<u64> {
                $dispatch!(self, remaining_operations())
            }

            fn residency_capacity_bytes(&self) -> usize {
                $dispatch!(self, residency_capacity_bytes())
            }

            fn supports_in_place_weight_preparation(&self) -> bool {
                $dispatch!(self, supports_in_place_weight_preparation())
            }

            fn prepare_weights(
                &mut self,
                columns: usize,
                rows: usize,
                weights: &[u8],
            ) -> Result<Option<NativeQ2WeightHandle>, Error> {
                $dispatch!(self, prepare_weights(columns, rows, weights))
            }

            fn prepare_weights_in_place(
                &mut self,
                columns: usize,
                rows: usize,
                initialize: &mut dyn FnMut(&mut [u8]) -> Result<(), Error>,
            ) -> Result<Option<NativeQ2WeightHandle>, Error> {
                $dispatch!(self, prepare_weights_in_place(columns, rows, initialize))
            }

            fn submit_resident(
                &mut self,
                handle: &NativeQ2WeightHandle,
                activation: &[f32],
                output: &mut [f32],
            ) -> Result<(), Error> {
                $dispatch!(self, submit_resident(handle, activation, output))
            }

            fn submit_resident_validated<'a>(
                &mut self,
                handle: &NativeQ2WeightHandle,
                activation: &[f32],
                output: &'a mut [f32],
            ) -> Result<NativeQ2ValidatedOutputs<'a, 1>, Error> {
                $dispatch!(self, submit_resident_validated(handle, activation, output))
            }

            fn submit_resident_batch2(
                &mut self,
                handles: [&NativeQ2WeightHandle; 2],
                activation: &[f32],
                outputs: [&mut [f32]; 2],
            ) -> Result<(), Error> {
                $dispatch!(self, submit_resident_batch2(handles, activation, outputs))
            }

            fn submit_resident_batch2_validated<'a>(
                &mut self,
                handles: [&NativeQ2WeightHandle; 2],
                activation: &[f32],
                outputs: [&'a mut [f32]; 2],
            ) -> Result<NativeQ2ValidatedOutputs<'a, 2>, Error> {
                $dispatch!(
                    self,
                    submit_resident_batch2_validated(handles, activation, outputs)
                )
            }

            fn submit_resident_batch3(
                &mut self,
                handles: [&NativeQ2WeightHandle; 3],
                activation: &[f32],
                outputs: [&mut [f32]; 3],
            ) -> Result<(), Error> {
                $dispatch!(self, submit_resident_batch3(handles, activation, outputs))
            }

            fn submit_resident_batch3_validated<'a>(
                &mut self,
                handles: [&NativeQ2WeightHandle; 3],
                activation: &[f32],
                outputs: [&'a mut [f32]; 3],
            ) -> Result<NativeQ2ValidatedOutputs<'a, 3>, Error> {
                $dispatch!(
                    self,
                    submit_resident_batch3_validated(handles, activation, outputs)
                )
            }

            fn submit_resident_multi2(
                &mut self,
                handles: [&NativeQ2WeightHandle; 2],
                activations: [&[f32]; 2],
                outputs: [&mut [f32]; 2],
            ) -> Result<(), Error> {
                $dispatch!(self, submit_resident_multi2(handles, activations, outputs))
            }

            fn submit_resident_multi3(
                &mut self,
                handles: [&NativeQ2WeightHandle; 3],
                activations: [&[f32]; 3],
                outputs: [&mut [f32]; 3],
            ) -> Result<(), Error> {
                $dispatch!(self, submit_resident_multi3(handles, activations, outputs))
            }

            fn submit_resident_multi4(
                &mut self,
                handles: [&NativeQ2WeightHandle; 4],
                activations: [&[f32]; 4],
                outputs: [&mut [f32]; 4],
            ) -> Result<(), Error> {
                $dispatch!(self, submit_resident_multi4(handles, activations, outputs))
            }

            fn submit_resident_multi8(
                &mut self,
                handles: [&NativeQ2WeightHandle; 8],
                activations: [&[f32]; 8],
                outputs: [&mut [f32]; 8],
            ) -> Result<(), Error> {
                $dispatch!(self, submit_resident_multi8(handles, activations, outputs))
            }

            fn submit_resident_ffn_swiglu(
                &mut self,
                gate_handle: &NativeQ2WeightHandle,
                up_handle: &NativeQ2WeightHandle,
                activation: &[f32],
                output: &mut [f32],
            ) -> Result<(), Error> {
                $dispatch!(
                    self,
                    submit_resident_ffn_swiglu(gate_handle, up_handle, activation, output)
                )
            }

            fn submit_resident_ffn_swiglu_multi2(
                &mut self,
                gate_handle: &NativeQ2WeightHandle,
                up_handle: &NativeQ2WeightHandle,
                activations: [&[f32]; 2],
                outputs: [&mut [f32]; 2],
            ) -> Result<(), Error> {
                $dispatch!(
                    self,
                    submit_resident_ffn_swiglu_multi2(gate_handle, up_handle, activations, outputs)
                )
            }

            fn submit_resident_ffn_chain(
                &mut self,
                handles: [&NativeQ2WeightHandle; 3],
                activation: &[f32],
                residual: Option<&[f32]>,
                hadamard_block_size: Option<u32>,
                output: &mut [f32],
            ) -> Result<(), Error> {
                $dispatch!(
                    self,
                    submit_resident_ffn_chain(
                        handles,
                        activation,
                        residual,
                        hadamard_block_size,
                        output
                    )
                )
            }

            fn maximum_resident_token_batch(&self) -> usize {
                $dispatch!(self, maximum_resident_token_batch())
            }

            fn supports_ffn_chain_multi2(&self) -> bool {
                $dispatch!(self, supports_ffn_chain_multi2())
            }

            fn submit_resident_ffn_chain_multi2(
                &mut self,
                handles: [&NativeQ2WeightHandle; 3],
                activations: [&[f32]; 2],
                residuals: [Option<&[f32]>; 2],
                hadamard_block_size: Option<u32>,
                outputs: [&mut [f32]; 2],
            ) -> Result<(), Error> {
                $dispatch!(
                    self,
                    submit_resident_ffn_chain_multi2(
                        handles,
                        activations,
                        residuals,
                        hadamard_block_size,
                        outputs
                    )
                )
            }

            fn submit(
                &mut self,
                columns: usize,
                rows: usize,
                weights: &[u8],
                activation: &[f32],
                output: &mut [f32],
            ) -> Result<(), Error> {
                $dispatch!(self, submit(columns, rows, weights, activation, output))
            }
        }
    };
}

macro_rules! dispatch_native_q2_session {
    ($session:ident, $method:ident($($argument:expr),*)) => {{
        #[cfg(all(windows, target_arch = "aarch64"))]
        {
            $session.0.$method($($argument),*)
        }
        #[cfg(not(all(windows, target_arch = "aarch64")))]
        {
            let _ = ($($argument,)*);
            match $session.0 {}
        }
    }};
}

impl_native_q2_session_forwarding!(NativeQ2Session, dispatch_native_q2_session);

#[cfg(test)]
mod native_q2_forwarding_tests;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exact_capability_layout_and_architecture_contract() -> Result<(), Error> {
        self_check()
    }

    #[test]
    fn raw_architecture_does_not_become_a_family_assumption() {
        assert_eq!(decode_architecture(0xffff_0081), Some(81));
        assert_eq!(decode_architecture(0x8f), None);
        assert_eq!(decode_architecture(0xff), None);
        assert_eq!(decode_architecture(0x02), None);
    }

    #[test]
    fn partial_mapping_receipts_never_claim_a_complete_cycle() {
        let mut report = MappingProbeReport::new();
        report.allocation_succeeded = true;
        report.descriptor_observed = true;
        report.cpu_roundtrip_verified = true;
        report.mapping_attempted = true;
        report.mapping_result = Some(0);
        report.unmapping_result = Some(0);
        report.free_completed = true;
        assert!(report.completed_mapping_cycle());
        report.poisoned = true;
        assert!(!report.completed_mapping_cycle());
        report.poisoned = false;
        report.unmapping_result = Some(-1);
        assert!(!report.completed_mapping_cycle());
        report.unmapping_result = None;
        assert!(!report.completed_mapping_cycle());
    }
}
