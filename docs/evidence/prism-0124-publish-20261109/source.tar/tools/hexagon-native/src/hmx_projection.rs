//! Fixed signed-source HMX bitplane packet and bounded terminal-session inputs.
#![expect(
    clippy::redundant_pub_crate,
    reason = "Packet helpers are shared only with the audited native sibling"
)]
#![cfg_attr(
    not(all(windows, target_arch = "aarch64")),
    allow(
        dead_code,
        reason = "Packet helpers are exercised by hosted controls and native Windows ARM64 sessions"
    )
)]

use crate::{Error, Q2ProjectionLimits, Q2ProjectionReport, compute, projection};
use std::ops::Range;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

static NEXT_HMX_REGISTRY_OWNER: AtomicU64 = AtomicU64::new(1);

/// Fixed 2 MiB VTCM request (of 8 MiB hardware VTCM) used to derive the HMX chunks; refusal never falls back.
pub const HMX_Q2_VTCM_REQUEST_BYTES: u32 = 2_097_152;
/// Fixed 128-byte HVX worker count for HMX sessions on the 8-HVX v81 CDSP domain.
pub const HMX_Q2_HVX_WORKERS: u32 = 8;
/// Fixed F32-to-F16 activation worker count (`min(n_threads, K / 32)` for `K = 128`).
pub const HMX_Q2_ACT_WORKERS: u8 = 4;
/// Fixed `HTP_POWER_MODE_BURST` (`7`) value pinning core/bus/HMX voltage corners during active HMX sessions.
pub const HMX_Q2_POWER_MODE_BURST: u32 = 7;
/// Maximum opt-in host-mapped immutable packed-weight arena; this is not VTCM.
pub const HMX_Q2_MAX_RESIDENT_WEIGHT_BYTES: usize = 64 * 1024 * 1024;
/// Fixed logical operation count in one batched HMX bitplane packet.
pub const HMX_Q2_BATCH_OPERATIONS: usize = 4;
/// Command header bytes for one buffer, twelve tensors, four operations and four reserved profile records.
pub const HMX_Q2_BATCH_COMMAND_BYTES: usize = 24 + HMX_Q2_BATCH_OPERATIONS * (3 * 56 + 232 + 48);
/// Fixed logical operation count in one ten-operation batched HMX bitplane packet.
pub const HMX_Q2_BATCH10_OPERATIONS: usize = 10;
/// Command header bytes for one buffer, thirty tensors, ten operations and ten reserved profile records.
pub const HMX_Q2_BATCH10_COMMAND_BYTES: usize =
    24 + HMX_Q2_BATCH10_OPERATIONS * (3 * 56 + 232 + 48);

/// One terminal K=128/N=8 bitplane session's explicit lifetime and work limits.
#[derive(Clone, Copy, Debug)]
pub struct HmxQ2ProjectionLimits {
    pub(crate) common: Q2ProjectionLimits,
    pub(crate) resident_weight_bytes: usize,
    pub(crate) batch_operations: usize,
}

impl HmxQ2ProjectionLimits {
    /// Validate 32-row multiples up to 17,408, at most 24,000 write attempts and
    /// one 4..=120-second allowance including initialization and cleanup.
    ///
    /// # Errors
    /// Rejects unsupported extents or bounds before any native operation.
    pub fn new(rows: usize, operations: u32, duration: Duration) -> Result<Self, Error> {
        Ok(Self {
            common: Q2ProjectionLimits::new(rows, operations, duration)?,
            resident_weight_bytes: 0,
            batch_operations: 1,
        })
    }

    /// Select the fixed four-operation batch packet layout (`12` tensors, `4` ops).
    ///
    /// Logical operation capacity remains bounded by `maximum_operations` (`24,000`
    /// ceiling), and each batch submission reserves four logical attempts before
    /// issuing one queue write.
    ///
    /// # Errors
    /// Rejects sessions whose logical operation allowance is smaller than four or
    /// that have already selected a different batch mode.
    pub const fn with_batch_four(mut self) -> Result<Self, Error> {
        if self.common.operations < 4 || self.batch_operations != 1 {
            return Err(Error::Contract);
        }
        self.batch_operations = HMX_Q2_BATCH_OPERATIONS;
        Ok(self)
    }

    /// Select the fixed ten-operation batch packet layout (`30` tensors, `10` ops).
    ///
    /// Logical operation capacity remains bounded by `maximum_operations` (`24,000`
    /// ceiling), and each batch submission reserves ten logical attempts before
    /// issuing one queue write (`4` queue writes per 40-block `5120`-column projection).
    ///
    /// # Errors
    /// Rejects sessions whose logical operation allowance is smaller than ten or
    /// that have already selected a different batch mode.
    pub const fn with_batch_ten(mut self) -> Result<Self, Error> {
        if self.common.operations < 10 || self.batch_operations != 1 {
            return Err(Error::Contract);
        }
        self.batch_operations = HMX_Q2_BATCH10_OPERATIONS;
        Ok(self)
    }

    /// Logical operations carried in each queue write packet (`1`, `4` or `10`).
    #[must_use]
    pub const fn batch_operations(self) -> usize {
        self.batch_operations
    }

    /// Reserve an optional immutable host-mapped weight arena in the same FD.
    ///
    /// This increases the allocation bound, without changing VTCM, operation or
    /// lifetime limits. The caller separately admits these bytes. Existing
    /// whole-allocation cache flags remain unchanged; no reduced DMA or cache
    /// traffic follows from avoiding repeated host tile copies.
    ///
    /// # Errors
    /// Rejects more than 64 MiB before opening a module or allocating memory.
    pub const fn with_resident_weights(mut self, bytes: usize) -> Result<Self, Error> {
        if bytes > HMX_Q2_MAX_RESIDENT_WEIGHT_BYTES {
            return Err(Error::Contract);
        }
        self.resident_weight_bytes = bytes;
        Ok(self)
    }

    /// Explicit opt-in immutable packed-weight payload capacity, excluding padding.
    #[must_use]
    pub const fn resident_weight_bytes(self) -> usize {
        self.resident_weight_bytes
    }

    /// Largest active output-row extent for one operation.
    #[must_use]
    pub const fn maximum_rows(self) -> usize {
        self.common.maximum_rows()
    }
    /// Maximum mapped host allocation, including the command and eight outputs.
    #[must_use]
    pub const fn allocation_bytes(self) -> usize {
        let working = match self.batch_operations {
            HMX_Q2_BATCH_OPERATIONS => batch_layout(self.common.rows).allocation,
            HMX_Q2_BATCH10_OPERATIONS => batch10_layout(self.common.rows).allocation,
            _ => layout(self.common.rows).allocation,
        };
        (working + self.resident_weight_bytes).next_multiple_of(4096)
    }
    /// Maximum single-attempt writes in the complete session.
    #[must_use]
    pub const fn maximum_operations(self) -> u32 {
        self.common.maximum_operations()
    }
    /// Absolute session allowance including the three-second cleanup reserve.
    #[must_use]
    pub const fn maximum_duration(self) -> Duration {
        self.common.maximum_duration()
    }
}

/// An immutable packed-weight extent owned by one submitter's registry.
///
/// The private owner identity prevents a handle from another session from
/// addressing native memory. Cloning a handle never extends a native session's
/// lifetime, frees storage or changes its append-only contents.
#[derive(Clone, Debug)]
pub struct HmxQ2WeightHandle {
    owner: u64,
    range: Range<usize>,
    rows: usize,
}

impl HmxQ2WeightHandle {
    /// Exact active weight-row count, always a positive multiple of 32.
    #[must_use]
    pub const fn rows(&self) -> usize {
        self.rows
    }

    /// Exact packed payload size, excluding alignment gaps.
    #[must_use]
    pub const fn packed_bytes(&self) -> usize {
        self.range.end - self.range.start
    }
}

/// Metadata-only append-only allocator for one submitter's packed-weight arena.
///
/// Custom model-free submitters may use this to issue and validate opaque
/// handles. The registry stores no payload or native pointer. The submitter
/// copies a successful reservation's bytes exactly once before exposing its
/// handle, and never changes or frees them while the session can consume them.
#[derive(Clone, Copy)]
pub struct HmxQ2WeightRegistry {
    owner: u64,
    capacity: usize,
    used: usize,
}

impl HmxQ2WeightRegistry {
    /// Create one independent owner with an explicitly admitted payload bound.
    ///
    /// # Errors
    /// Rejects capacity above the same 64 MiB native bound.
    pub fn new(capacity_bytes: usize) -> Result<Self, Error> {
        if capacity_bytes > HMX_Q2_MAX_RESIDENT_WEIGHT_BYTES {
            return Err(Error::Contract);
        }
        Ok(Self {
            owner: NEXT_HMX_REGISTRY_OWNER.fetch_add(1, Ordering::Relaxed),
            capacity: capacity_bytes,
            used: 0,
        })
    }

    /// Remaining payload extent, including alignment charged by prior reservations.
    #[must_use]
    pub const fn remaining_bytes(&self) -> usize {
        self.capacity - self.used
    }

    /// Validate and reserve one immutable, 128-byte-aligned packed-weight extent.
    ///
    /// `None` means insufficient capacity and leaves the registry unchanged.
    /// This consumes no native operation. No reservation is ever evicted/reused.
    ///
    /// # Errors
    /// Rejects malformed geometry or non-unit packed scales before reservation.
    pub fn prepare(&mut self, weights: &[u8]) -> Result<Option<HmxQ2WeightHandle>, Error> {
        let rows = validate_weights(projection::Q2_PROJECTION_MAX_ROWS, weights)?;
        let start = self.used.next_multiple_of(128);
        let end = start.checked_add(weights.len()).ok_or(Error::Contract)?;
        if end > self.capacity {
            return Ok(None);
        }
        self.used = end;
        Ok(Some(HmxQ2WeightHandle {
            owner: self.owner,
            range: start..end,
            rows,
        }))
    }

    /// Recover an owner-checked byte range inside this registry's arena.
    ///
    /// # Errors
    /// Rejects handles issued by any other registry, including earlier sessions.
    pub fn range(&self, handle: &HmxQ2WeightHandle) -> Result<Range<usize>, Error> {
        if self.owner != handle.owner
            || handle.range.end > self.used
            || handle.range.end > self.capacity
        {
            return Err(Error::Contract);
        }
        Ok(handle.range.clone())
    }
}

/// Terminal HMX session report with the same explicit lifetime observations.
/// Check [`Q2ProjectionReport::is_hmx_bitplane_control`] before consuming it as HMX evidence.
pub type HmxQ2ProjectionReport = Q2ProjectionReport;

/// Synchronous exact integer bitplane submission to the fixed source HMX path.
pub trait HmxQ2Submitter {
    /// Remaining writes in the actual borrowed native session, when known.
    ///
    /// Custom submitters returning `None` require independently matched limits.
    /// Native sessions include all earlier work, including previous executors.
    fn remaining_operations(&self) -> Option<u64> {
        None
    }

    /// Remaining optional immutable host-mapped weight capacity, including padding.
    /// The default submitter supports no residency and preserves ordinary submission.
    fn residency_capacity_bytes(&self) -> usize {
        0
    }

    /// Copy immutable packed weights into an optional session-owned arena once.
    ///
    /// Capacity refusal returns `None` without consuming an operation or
    /// faulting a healthy native session. Custom submitters may use
    /// [`HmxQ2WeightRegistry`] to issue owner-checked handles.
    ///
    /// # Errors
    /// Malformed weights or an expired/faulted native session reject explicitly.
    fn prepare_weights(&mut self, _weights: &[u8]) -> Result<Option<HmxQ2WeightHandle>, Error> {
        Ok(None)
    }

    /// Submit a previously prepared immutable extent without copying its weights.
    ///
    /// Geometry, activation, queue correlation, work and deadline checks match
    /// ordinary submission. The handle must belong to this exact session.
    ///
    /// # Errors
    /// Unsupported residency, foreign handles and submission failures reject;
    /// native failures permanently close the session with no CPU replay.
    fn submit_resident(
        &mut self,
        _handle: &HmxQ2WeightHandle,
        _activation: &[[f32; 128]; 8],
        output: &mut [f32],
    ) -> Result<(), Error> {
        output.fill(f32::NAN);
        Err(Error::Contract)
    }

    /// Submit unit-scale tiled Q2 weights and eight binary F32 K=128 planes.
    /// `output` is contiguous `[plane][M-row]`, with M a multiple of 32.
    /// All correlated outputs must be integral in -128..=256; the caller must
    /// additionally compare exact dots against an independent oracle.
    ///
    /// # Errors
    /// Any refusal, malformed output or deadline permanently closes this
    /// session and retains uncertain native owners until supervised exit.
    fn submit(
        &mut self,
        weights: &[u8],
        activation: &[[f32; 128]; 8],
        output: &mut [f32],
    ) -> Result<(), Error>;

    /// Submit four independent K=128/N=8 bitplane operations in one queue packet.
    ///
    /// All four members must share the same active row extent and pass tile/plane
    /// validation before the single packet write. All four outputs are validated
    /// before any caller slice is populated.
    ///
    /// # Errors
    /// Rejects unconfigured batch mode, malformed inputs, insufficient remaining
    /// four-operation capacity, native failures, deadlines and invalid outputs.
    fn submit_batch4(
        &mut self,
        _weights: [&[u8]; HMX_Q2_BATCH_OPERATIONS],
        _activations: [&[[f32; 128]; 8]; HMX_Q2_BATCH_OPERATIONS],
        outputs: [&mut [f32]; HMX_Q2_BATCH_OPERATIONS],
    ) -> Result<(), Error> {
        for output in outputs {
            output.fill(f32::NAN);
        }
        Err(Error::Contract)
    }

    /// Submit four previously prepared resident-weight extents in one queue packet.
    ///
    /// All four handles must belong to this session and share the same row extent.
    ///
    /// # Errors
    /// Rejects unconfigured batch mode or residency, foreign handles, insufficient
    /// four-operation capacity, native failures, deadlines and invalid outputs.
    fn submit_resident_batch4(
        &mut self,
        _handles: [&HmxQ2WeightHandle; HMX_Q2_BATCH_OPERATIONS],
        _activations: [&[[f32; 128]; 8]; HMX_Q2_BATCH_OPERATIONS],
        outputs: [&mut [f32]; HMX_Q2_BATCH_OPERATIONS],
    ) -> Result<(), Error> {
        for output in outputs {
            output.fill(f32::NAN);
        }
        Err(Error::Contract)
    }

    /// Submit ten independent K=128/N=8 bitplane operations in one queue packet.
    ///
    /// All ten members must share the same active row extent and pass tile/plane
    /// validation before the single packet write. All ten outputs are validated
    /// before any caller slice is populated.
    ///
    /// # Errors
    /// Rejects unconfigured ten-operation batch mode, malformed inputs, insufficient
    /// ten-operation capacity, native failures, deadlines and invalid outputs.
    fn submit_batch10(
        &mut self,
        _weights: [&[u8]; HMX_Q2_BATCH10_OPERATIONS],
        _activations: [&[[f32; 128]; 8]; HMX_Q2_BATCH10_OPERATIONS],
        outputs: [&mut [f32]; HMX_Q2_BATCH10_OPERATIONS],
    ) -> Result<(), Error> {
        for output in outputs {
            output.fill(f32::NAN);
        }
        Err(Error::Contract)
    }

    /// Submit ten previously prepared resident-weight extents in one queue packet.
    ///
    /// All ten handles must belong to this session and share the same row extent.
    ///
    /// # Errors
    /// Rejects unconfigured ten-operation batch mode or residency, foreign handles,
    /// insufficient capacity, native failures, deadlines and invalid outputs.
    fn submit_resident_batch10(
        &mut self,
        _handles: [&HmxQ2WeightHandle; HMX_Q2_BATCH10_OPERATIONS],
        _activations: [&[[f32; 128]; 8]; HMX_Q2_BATCH10_OPERATIONS],
        outputs: [&mut [f32]; HMX_Q2_BATCH10_OPERATIONS],
    ) -> Result<(), Error> {
        for output in outputs {
            output.fill(f32::NAN);
        }
        Err(Error::Contract)
    }
}

pub(crate) const fn layout(rows: usize) -> projection::Layout {
    let weights = rows / 32 * 1152;
    let activation = (1024 + weights).next_multiple_of(128);
    let output = activation + 4096;
    projection::Layout {
        weights,
        activation,
        output,
        allocation: (output + rows * 32).next_multiple_of(4096),
    }
}

pub(crate) const fn batch_layout(rows: usize) -> projection::Layout {
    batch_n_layout::<HMX_Q2_BATCH_OPERATIONS, 2048>(rows)
}

pub(crate) const fn batch10_layout(rows: usize) -> projection::Layout {
    batch_n_layout::<HMX_Q2_BATCH10_OPERATIONS, 8192>(rows)
}

pub(crate) const fn batch_n_layout<const B: usize, const CMD_PAD: usize>(
    rows: usize,
) -> projection::Layout {
    let weights = rows / 32 * 1152;
    let activation = (CMD_PAD + B * weights).next_multiple_of(128);
    let output = activation + B * 4096;
    projection::Layout {
        weights,
        activation,
        output,
        allocation: (output + B * rows * 32).next_multiple_of(4096),
    }
}

pub(crate) fn start_wire(queue_id: u64, allocation: usize) -> Result<[u8; 48], Error> {
    let mut result = compute::start_wire(queue_id);
    put32(&mut result, 16, HMX_Q2_HVX_WORKERS);
    put32(&mut result, 20, 1);
    put32(&mut result, 24, HMX_Q2_VTCM_REQUEST_BYTES);
    put32(&mut result, 40, HMX_Q2_POWER_MODE_BURST);
    put64(
        &mut result,
        32,
        u64::try_from(allocation).map_err(|_| Error::Contract)?,
    );
    Ok(result)
}

// Specialization of htp_mm_hmx_compute_chunks and solve_2d_params at pinned
// 19cce691: K128, m8 padded32, Q2_0, 8 HVX threads (4 act threads), no pipeline/bias, 2 MiB VTCM.
// Per-N=2*640/32+128*2=296, per-M=256, per-MN=2, overhead=5*2048+256.
// Cost ties prefer least tail waste then largest mc*nc, as the source does.
pub(crate) fn chunks(rows: usize) -> Result<(u32, u32), Error> {
    let vtcm_budget = usize::try_from(HMX_Q2_VTCM_REQUEST_BYTES).map_err(|_| Error::Contract)?;
    let usable = vtcm_budget - 10_496;
    let mut best: Option<(usize, usize, usize)> = None;
    for columns in (32..=rows.min(usable / 296)).step_by(32) {
        let remaining = usable - columns * 296;
        let mc = (remaining / (256 + columns * 2) / 32 * 32).min(32);
        if mc == 0 {
            continue;
        }
        let blocks = rows.div_ceil(columns);
        let waste = if rows.is_multiple_of(columns) {
            0
        } else {
            columns - rows % columns
        };
        if best.is_none_or(|(best_blocks, best_waste, best_columns)| {
            (blocks, waste, std::cmp::Reverse(columns))
                < (best_blocks, best_waste, std::cmp::Reverse(best_columns))
        }) {
            best = Some((blocks, waste, columns));
        }
    }
    let (_, _, columns) = best.ok_or(Error::Contract)?;
    // Exact htp_mm_hmx_vtcm_layout_build, not its conservative cost estimate.
    let weight = (columns / 32 * 2 * 640).next_multiple_of(2048);
    let output = (32 * columns * 2).next_multiple_of(2048);
    let scratch = (columns * 256).next_multiple_of(2048);
    let compute_group = weight + output + scratch;
    let activation_temp = compute_group.clamp(4096, 131_072).next_multiple_of(128);
    let bytes = 2048 + 8192 + compute_group.max(activation_temp);
    if bytes > vtcm_budget {
        return Err(Error::Contract);
    }
    Ok((
        u32::try_from(columns).map_err(|_| Error::Contract)?,
        u32::try_from(bytes).map_err(|_| Error::Contract)?,
    ))
}

pub(crate) fn validate_inputs(
    maximum_rows: usize,
    weights: &[u8],
    activation: &[[f32; 128]; 8],
    outputs: usize,
) -> Result<usize, Error> {
    let rows = validate_weights(maximum_rows, weights)?;
    validate_activation(maximum_rows, rows, activation, outputs)?;
    Ok(rows)
}

pub(crate) fn validate_batch_inputs<const B: usize>(
    maximum_rows: usize,
    weights: [&[u8]; B],
    activations: [&[[f32; 128]; 8]; B],
    outputs: [usize; B],
) -> Result<usize, Error> {
    let rows = validate_inputs(maximum_rows, weights[0], activations[0], outputs[0])?;
    for member in 1..B {
        if validate_inputs(
            maximum_rows,
            weights[member],
            activations[member],
            outputs[member],
        )? != rows
        {
            return Err(Error::Contract);
        }
    }
    Ok(rows)
}

pub(crate) fn validate_batch_resident<const B: usize>(
    maximum_rows: usize,
    handles: [&HmxQ2WeightHandle; B],
    activations: [&[[f32; 128]; 8]; B],
    outputs: [usize; B],
) -> Result<usize, Error> {
    let rows = handles[0].rows();
    for member in 0..B {
        if handles[member].rows() != rows {
            return Err(Error::Contract);
        }
        validate_activation(maximum_rows, rows, activations[member], outputs[member])?;
    }
    Ok(rows)
}

pub(crate) fn validate_activation(
    maximum_rows: usize,
    rows: usize,
    activation: &[[f32; 128]; 8],
    outputs: usize,
) -> Result<(), Error> {
    if outputs / 8 != rows
        || !outputs.is_multiple_of(8)
        || rows == 0
        || rows > maximum_rows
        || !rows.is_multiple_of(32)
    {
        return Err(Error::Contract);
    }
    if activation
        .iter()
        .flatten()
        .any(|value| !matches!(value.to_bits(), 0 | 0x3f80_0000))
    {
        return Err(Error::Contract);
    }
    Ok(())
}

fn validate_weights(maximum_rows: usize, weights: &[u8]) -> Result<usize, Error> {
    let rows = weights.len() / 36;
    if rows == 0
        || rows > maximum_rows
        || !rows.is_multiple_of(32)
        || weights.len() != layout(rows).weights
        || weights.as_chunks::<576>().0.iter().any(|tile| {
            tile[512..]
                .as_chunks::<2>()
                .0
                .iter()
                .any(|scale| *scale != [0, 0x3c])
        })
    {
        return Err(Error::Contract);
    }
    Ok(rows)
}

pub(crate) fn image(
    bytes: &mut [u8],
    base: u64,
    fd: u32,
    rows: usize,
    weights: &[u8],
    activation: &[[f32; 128]; 8],
) -> Result<projection::Layout, Error> {
    let active = frame(bytes, base, fd, rows, activation)?;
    if weights.len() != active.weights {
        return Err(Error::Contract);
    }
    bytes[1024..1024 + weights.len()].copy_from_slice(weights);
    Ok(active)
}

pub(crate) fn image_resident(
    bytes: &mut [u8],
    base: u64,
    fd: u32,
    arena_start: usize,
    handle: &HmxQ2WeightHandle,
    activation: &[[f32; 128]; 8],
) -> Result<projection::Layout, Error> {
    let allocation = bytes.len();
    let weight_offset = arena_start
        .checked_add(handle.range.start)
        .ok_or(Error::Contract)?;
    let weight_end = arena_start
        .checked_add(handle.range.end)
        .ok_or(Error::Contract)?;
    if weight_end > allocation || handle.packed_bytes() != layout(handle.rows).weights {
        return Err(Error::Contract);
    }
    let working = bytes.get_mut(..arena_start).ok_or(Error::Contract)?;
    let active = frame(working, base, fd, handle.rows, activation)?;
    put64(
        bytes,
        8,
        u64::try_from(allocation).map_err(|_| Error::Contract)?,
    );
    put64(
        bytes,
        24,
        u64::try_from(weight_offset).map_err(|_| Error::Contract)?,
    );
    Ok(active)
}

pub(crate) fn image_batch<const B: usize, const CMD_PAD: usize>(
    bytes: &mut [u8],
    base: u64,
    fd: u32,
    rows: usize,
    weights: [&[u8]; B],
    activations: [&[[f32; 128]; 8]; B],
) -> Result<projection::Layout, Error> {
    let active = batch_n_layout::<B, CMD_PAD>(rows);
    let weight_offsets = std::array::from_fn(|member| CMD_PAD + member * active.weights);
    let active = frame_batch::<B, CMD_PAD>(bytes, base, fd, rows, weight_offsets, activations)?;
    for (member, weight) in weights.into_iter().enumerate() {
        if weight.len() != active.weights {
            return Err(Error::Contract);
        }
        let start = CMD_PAD + member * active.weights;
        bytes[start..start + active.weights].copy_from_slice(weight);
    }
    Ok(active)
}

pub(crate) fn image_batch_resident<const B: usize, const CMD_PAD: usize>(
    bytes: &mut [u8],
    base: u64,
    fd: u32,
    arena_start: usize,
    handles: [&HmxQ2WeightHandle; B],
    activations: [&[[f32; 128]; 8]; B],
) -> Result<projection::Layout, Error> {
    let allocation = bytes.len();
    let rows = handles[0].rows;
    let expected_weights = batch_n_layout::<B, CMD_PAD>(rows).weights;
    let mut weight_offsets = [0_usize; B];
    for (member, handle) in handles.into_iter().enumerate() {
        let start = arena_start
            .checked_add(handle.range.start)
            .ok_or(Error::Contract)?;
        let end = arena_start
            .checked_add(handle.range.end)
            .ok_or(Error::Contract)?;
        if handle.rows != rows || end > allocation || handle.packed_bytes() != expected_weights {
            return Err(Error::Contract);
        }
        weight_offsets[member] = start;
    }
    let working = bytes.get_mut(..arena_start).ok_or(Error::Contract)?;
    let active = frame_batch::<B, CMD_PAD>(working, base, fd, rows, weight_offsets, activations)?;
    put64(
        bytes,
        8,
        u64::try_from(allocation).map_err(|_| Error::Contract)?,
    );
    Ok(active)
}

fn frame_batch<const B: usize, const CMD_PAD: usize>(
    bytes: &mut [u8],
    base: u64,
    fd: u32,
    rows: usize,
    weight_offsets: [usize; B],
    activations: [&[[f32; 128]; 8]; B],
) -> Result<projection::Layout, Error> {
    let active = batch_n_layout::<B, CMD_PAD>(rows);
    if bytes.len() < active.allocation
        || bytes.len() > batch_n_layout::<B, CMD_PAD>(projection::Q2_PROJECTION_MAX_ROWS).allocation
    {
        return Err(Error::Contract);
    }
    let mut single = [0_u8; 1024];
    write_single_header(&mut single, base, bytes.len(), fd, rows, layout(rows))?;
    bytes[..CMD_PAD].fill(0);
    bytes[..24].copy_from_slice(&single[..24]);
    put64(
        bytes,
        8,
        u64::try_from(bytes.len()).map_err(|_| Error::Contract)?,
    );
    let member_output_bytes = rows * 32;
    let operations_base = 24 + B * 3 * 56;
    for member in 0..B {
        let ti_base = u16::try_from(member * 3).map_err(|_| Error::Contract)?;
        let weight_desc = 24 + (member * 3) * 56;
        let act_desc = weight_desc + 56;
        let out_desc = act_desc + 56;
        bytes[weight_desc..weight_desc + 56].copy_from_slice(&single[24..80]);
        bytes[act_desc..act_desc + 56].copy_from_slice(&single[80..136]);
        bytes[out_desc..out_desc + 56].copy_from_slice(&single[136..192]);
        put64(
            bytes,
            weight_desc,
            u64::try_from(weight_offsets[member]).map_err(|_| Error::Contract)?,
        );
        put16(bytes, weight_desc + 22, ti_base);
        let member_activation = active.activation + member * 4096;
        put64(
            bytes,
            act_desc,
            u64::try_from(member_activation).map_err(|_| Error::Contract)?,
        );
        put16(bytes, act_desc + 22, ti_base + 1);
        let member_output = active.output + member * member_output_bytes;
        put64(
            bytes,
            out_desc,
            u64::try_from(member_output).map_err(|_| Error::Contract)?,
        );
        put16(bytes, out_desc + 22, ti_base + 2);
        let operation_desc = operations_base + member * 232;
        bytes[operation_desc..operation_desc + 232].copy_from_slice(&single[192..424]);
        put16(bytes, operation_desc + 200, ti_base);
        put16(bytes, operation_desc + 202, ti_base + 1);
        put16(bytes, operation_desc + 220, ti_base + 2);
        for (dst, value) in bytes[member_activation..member_activation + 4096]
            .as_chunks_mut::<4>()
            .0
            .iter_mut()
            .zip(activations[member].iter().flatten())
        {
            *dst = value.to_bits().to_le_bytes();
        }
    }
    let total_output_words = B * rows * 8;
    for dst in bytes[active.output..active.output + total_output_words * 4]
        .as_chunks_mut::<4>()
        .0
    {
        *dst = 0x7fc0_ae51_u32.to_le_bytes();
    }
    bytes[active.output + total_output_words * 4..].fill(0);
    Ok(active)
}

fn write_single_header(
    bytes: &mut [u8; 1024],
    base: u64,
    allocation_bytes: usize,
    fd: u32,
    rows: usize,
    active: projection::Layout,
) -> Result<(), Error> {
    const KP: usize = 264;
    let (n_chunk, vtcm_size) = chunks(rows)?;
    *bytes = compute::q2_framing_header(base, fd);
    put64(
        bytes,
        8,
        u64::try_from(allocation_bytes).map_err(|_| Error::Contract)?,
    );
    // Weight tensor: Q2_0 K128/M rows, WEIGHT|TILED, 36 logical bytes/row.
    for (offset, value) in [
        (32, active.weights),
        (48, 128),
        (52, rows),
        (64, 18),
        (68, 36),
        (72, active.weights),
        (76, active.weights),
        (88, 4096),
        (104, 128),
        (108, 8),
        (120, 4),
        (124, 512),
        (128, 4096),
        (132, 4096),
        (144, rows * 32),
        (160, rows),
        (164, 8),
        (176, 4),
        (180, rows * 4),
        (184, rows * 32),
        (188, rows * 32),
    ] {
        put32(
            bytes,
            offset,
            u32::try_from(value).map_err(|_| Error::Contract)?,
        );
    }
    put64(
        bytes,
        80,
        u64::try_from(active.activation).map_err(|_| Error::Contract)?,
    );
    put64(
        bytes,
        136,
        u64::try_from(active.output).map_err(|_| Error::Contract)?,
    );
    bytes[KP..KP + 128].fill(0);
    bytes[KP] = 1; // HTP_MM_KERNEL_HMX_2D.
    bytes[KP + 3] = 1; // n_hmx; no pipeline for N8.
    bytes[KP + 4] = u8::try_from(HMX_Q2_HVX_WORKERS).map_err(|_| Error::Contract)?; // eight HVX workers.
    bytes[KP + 5] = HMX_Q2_ACT_WORKERS; // four F32->F16 activation workers.
    for (offset, value) in [
        (8, 32),
        (12, n_chunk),
        (16, 576),
        (20, 640),
        (24, 5120),
        (28, vtcm_size),
    ] {
        put32(bytes, KP + offset, value);
    }
    // fastdiv(8)=(1,3), (1)=(1,0), (128)=(1,7).
    for (index, shift) in [3, 3, 0, 0, 0, 2, 7].into_iter().enumerate() {
        put32(bytes, KP + 36 + index * 8, 1);
        put32(bytes, KP + 40 + index * 8, shift);
    }
    Ok(())
}

fn frame(
    bytes: &mut [u8],
    base: u64,
    fd: u32,
    rows: usize,
    activation: &[[f32; 128]; 8],
) -> Result<projection::Layout, Error> {
    let active = layout(rows);
    if bytes.len() < active.allocation
        || bytes.len() > layout(projection::Q2_PROJECTION_MAX_ROWS).allocation
    {
        return Err(Error::Contract);
    }
    let allocation_bytes = bytes.len();
    let mut header = [0_u8; 1024];
    write_single_header(&mut header, base, allocation_bytes, fd, rows, active)?;
    bytes[..1024].copy_from_slice(&header);
    for (dst, value) in bytes[active.activation..active.activation + 4096]
        .as_chunks_mut::<4>()
        .0
        .iter_mut()
        .zip(activation.iter().flatten())
    {
        *dst = value.to_bits().to_le_bytes();
    }
    let output_bytes = rows * 32;
    for dst in bytes[active.output..active.output + output_bytes]
        .as_chunks_mut::<4>()
        .0
    {
        *dst = 0x7fc0_ae51_u32.to_le_bytes();
    }
    bytes[active.output + output_bytes..].fill(0);
    Ok(active)
}

#[expect(
    clippy::as_conversions,
    clippy::cast_possible_truncation,
    clippy::float_cmp,
    reason = "Exact i16 roundtrip rejects NaN, infinities, fractions and out-of-range plane sums without scalar truncf calls."
)]
pub(crate) fn output_valid(bytes: &[u8]) -> bool {
    !bytes.is_empty()
        && bytes.len().is_multiple_of(4)
        && bytes.as_chunks::<4>().0.iter().all(|value| {
            let value = f32::from_le_bytes(*value);
            let integer = value as i16;
            f32::from(integer) == value && (-128..=256).contains(&integer)
        })
}

fn put16(bytes: &mut [u8], offset: usize, value: u16) {
    bytes[offset..offset + 2].copy_from_slice(&value.to_le_bytes());
}
fn put32(bytes: &mut [u8], offset: usize, value: u32) {
    bytes[offset..offset + 4].copy_from_slice(&value.to_le_bytes());
}
fn put64(bytes: &mut [u8], offset: usize, value: u64) {
    bytes[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hmx_limits_share_the_authorized_cap_without_extending_time_or_allocation()
    -> Result<(), Error> {
        let limits = HmxQ2ProjectionLimits::new(17_408, 24_000, Duration::from_mins(2))?;
        assert_eq!(
            limits.maximum_operations(),
            projection::Q2_PROJECTION_MAX_OPERATIONS
        );
        assert_eq!(limits.maximum_duration(), Duration::from_mins(2));
        assert_eq!(limits.allocation_bytes(), 1_191_936);
        for operations in [0, 24_001, u32::MAX] {
            assert!(HmxQ2ProjectionLimits::new(32, operations, Duration::from_secs(4)).is_err());
        }
        assert!(HmxQ2ProjectionLimits::new(32, 24_000, Duration::from_secs(121)).is_err());
        Ok(())
    }

    #[test]
    fn fixed_hmx_solver_and_frame_keep_eight_planes_and_exact_bounded_extents() -> Result<(), Error>
    {
        assert_eq!(chunks(32)?, (32, 22528));
        assert_eq!(chunks(64)?, (64, 34816));
        assert_eq!(chunks(17_408)?, (4352, 1_576_960));
        let limits = HmxQ2ProjectionLimits::new(17_408, 40, Duration::from_secs(20))?;
        assert_eq!(limits.allocation_bytes(), 1_191_936);
        let start = start_wire(0x1234, limits.allocation_bytes())?;
        assert_eq!(&start[16..28], &[8, 0, 0, 0, 1, 0, 0, 0, 0, 0, 32, 0]);
        assert_eq!(&start[40..44], &[7, 0, 0, 0]);
        let mut weights = vec![0x55; 1152];
        for tile in weights.as_chunks_mut::<576>().0 {
            for scale in tile[512..].as_chunks_mut::<2>().0 {
                *scale = [0, 0x3c];
            }
        }
        let activation = [[1.0; 128]; 8];
        assert_eq!(validate_inputs(32, &weights, &activation, 256)?, 32);
        let mut bytes = vec![0; layout(32).allocation];
        let active = image(&mut bytes, 0x1234_5600, 7, 32, &weights, &activation)?;
        assert_eq!(&bytes[264..270], &[1, 0, 0, 1, 8, 4]);
        assert_eq!(&bytes[264 + 76..264 + 84], &[1, 0, 0, 0, 2, 0, 0, 0]);
        assert_eq!(&bytes[264 + 8..264 + 16], &[32, 0, 0, 0, 32, 0, 0, 0]);
        assert_eq!(&bytes[264 + 28..264 + 32], &22528_u32.to_le_bytes());
        assert!(!output_valid(&bytes[active.output..active.output + 1024]));
        let mut malformed = activation;
        malformed[0][0] = -0.0;
        assert!(validate_inputs(32, &weights, &malformed, 256).is_err());
        for value in [f32::NAN, f32::INFINITY, -129.0, 257.0, 0.5] {
            assert!(!output_valid(&value.to_le_bytes()));
        }
        for value in [-128.0_f32, 0.0, 256.0] {
            assert!(output_valid(&value.to_le_bytes()));
        }
        Ok(())
    }

    #[test]
    fn resident_registry_has_owner_identity_and_transactional_capacity_refusal() -> Result<(), Error>
    {
        let mut weights = vec![0x55; 1152];
        for tile in weights.as_chunks_mut::<576>().0 {
            for scale in tile[512..].as_chunks_mut::<2>().0 {
                *scale = [0, 0x3c];
            }
        }
        let mut owner = HmxQ2WeightRegistry::new(2304)?;
        let mut other = HmxQ2WeightRegistry::new(2304)?;
        let first = owner.prepare(&weights)?.ok_or(Error::Contract)?;
        let second = owner.prepare(&weights)?.ok_or(Error::Contract)?;
        assert_eq!(first.rows(), 32);
        assert_eq!(first.packed_bytes(), 1152);
        assert_eq!(owner.range(&first)?, 0..1152);
        assert_eq!(owner.range(&second)?, 1152..2304);
        assert_eq!(owner.remaining_bytes(), 0);
        assert!(owner.prepare(&weights)?.is_none());
        assert_eq!(owner.remaining_bytes(), 0);
        assert!(other.range(&first).is_err());
        let foreign = other.prepare(&weights)?.ok_or(Error::Contract)?;
        assert!(owner.range(&foreign).is_err());
        weights[512] = 1;
        assert!(other.prepare(&weights).is_err());
        assert_eq!(other.remaining_bytes(), 1152);
        assert!(HmxQ2WeightRegistry::new(HMX_Q2_MAX_RESIDENT_WEIGHT_BYTES + 1).is_err());
        let limits = HmxQ2ProjectionLimits::new(32, 3, Duration::from_secs(4))?;
        assert_eq!(limits.resident_weight_bytes(), 0);
        assert_eq!(limits.allocation_bytes(), 8192);
        let resident = limits.with_resident_weights(2304)?;
        assert_eq!(resident.resident_weight_bytes(), 2304);
        assert_eq!(resident.allocation_bytes(), 12288);
        assert_eq!(resident.maximum_operations(), limits.maximum_operations());
        assert_eq!(resident.maximum_duration(), limits.maximum_duration());
        assert!(
            limits
                .with_resident_weights(HMX_Q2_MAX_RESIDENT_WEIGHT_BYTES + 1)
                .is_err()
        );
        Ok(())
    }

    #[test]
    fn resident_frame_preserves_immutable_arena_and_signed_solver_fields() -> Result<(), Error> {
        let mut weights = vec![0x55; 1152];
        for tile in weights.as_chunks_mut::<576>().0 {
            for scale in tile[512..].as_chunks_mut::<2>().0 {
                *scale = [0, 0x3c];
            }
        }
        let mut registry = HmxQ2WeightRegistry::new(2304)?;
        let first = registry.prepare(&weights)?.ok_or(Error::Contract)?;
        let second = registry.prepare(&weights)?.ok_or(Error::Contract)?;
        let working_bytes = layout(32).allocation;
        let mut bytes = vec![0xa5; 12288];
        bytes[working_bytes..working_bytes + 1152].copy_from_slice(&weights);
        bytes[working_bytes + 1152..working_bytes + 2304].copy_from_slice(&weights);
        let retained = bytes[working_bytes..].to_vec();
        let activation = [[1.0; 128]; 8];
        let mut ordinary = vec![0; working_bytes];
        image(&mut ordinary, 0x1234, 7, 32, &weights, &activation)?;
        for handle in [&first, &second, &first] {
            let active = image_resident(&mut bytes, 0x1234, 7, working_bytes, handle, &activation)?;
            assert_eq!(&bytes[working_bytes..], &retained);
            assert_eq!(&bytes[8..16], &12288_u64.to_le_bytes());
            let offset = working_bytes + registry.range(handle)?.start;
            assert_eq!(
                &bytes[24..32],
                &u64::try_from(offset)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
            assert_eq!(&bytes[32..1024], &ordinary[32..1024]);
            assert_eq!(
                &bytes[active.activation..active.output],
                &ordinary[active.activation..active.output]
            );
            assert!(!output_valid(&bytes[active.output..active.output + 1024]));
        }
        Ok(())
    }

    #[test]
    #[expect(
        clippy::too_many_lines,
        reason = "Keep both streaming and resident batch-four frame layout checks together"
    )]
    fn batch4_frame_builds_twelve_tensors_four_ops_and_preserves_resident_arena()
    -> Result<(), Error> {
        assert_eq!(HMX_Q2_BATCH_OPERATIONS, 4);
        assert_eq!(HMX_Q2_BATCH_COMMAND_BYTES, 1816);
        assert!(
            HmxQ2ProjectionLimits::new(32, 3, Duration::from_secs(4))?
                .with_batch_four()
                .is_err()
        );
        let full =
            HmxQ2ProjectionLimits::new(17_408, 40, Duration::from_secs(20))?.with_batch_four()?;
        assert_eq!(full.batch_operations(), 4);
        assert_eq!(full.allocation_bytes(), 4_755_456);
        assert_eq!(
            full.with_resident_weights(25_067_520)?.allocation_bytes(),
            29_822_976
        );
        let mut weights = vec![0x55; 1152];
        for tile in weights.as_chunks_mut::<576>().0 {
            for scale in tile[512..].as_chunks_mut::<2>().0 {
                *scale = [0, 0x3c];
            }
        }
        let activations: [[[f32; 128]; 8]; 4] = std::array::from_fn(|member| {
            let mut planes = [[0.0_f32; 128]; 8];
            planes[member][0] = 1.0;
            planes
        });
        let activation_refs = [
            &activations[0],
            &activations[1],
            &activations[2],
            &activations[3],
        ];
        assert_eq!(
            validate_batch_inputs::<4>(32, [&weights; 4], activation_refs, [256; 4])?,
            32
        );
        let working = batch_layout(32);
        let mut streaming = vec![0xa5; working.allocation];
        image_batch::<4, 2048>(
            &mut streaming,
            0x1234_5600,
            7,
            32,
            [&weights; 4],
            activation_refs,
        )?;
        assert_eq!(&streaming[1624..2048], &[0; 424]);
        for member in 0..4 {
            let weight_desc = 24 + member * 3 * 56;
            let act_desc = weight_desc + 56;
            let out_desc = act_desc + 56;
            let operation_desc = 696 + member * 232;
            let ti = u16::try_from(member * 3).map_err(|_| Error::Contract)?;
            assert_eq!(
                &streaming[weight_desc..weight_desc + 8],
                &u64::try_from(2048 + member * 1152)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
            assert_eq!(
                &streaming[weight_desc + 22..weight_desc + 24],
                &ti.to_le_bytes()
            );
            assert_eq!(
                &streaming[act_desc..act_desc + 8],
                &u64::try_from(working.activation + member * 4096)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
            assert_eq!(
                &streaming[act_desc + 22..act_desc + 24],
                &(ti + 1).to_le_bytes()
            );
            assert_eq!(
                &streaming[out_desc..out_desc + 8],
                &u64::try_from(working.output + member * 1024)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
            assert_eq!(
                &streaming[out_desc + 22..out_desc + 24],
                &(ti + 2).to_le_bytes()
            );
            assert_eq!(
                &streaming[operation_desc + 200..operation_desc + 202],
                &ti.to_le_bytes()
            );
            assert_eq!(
                &streaming[operation_desc + 202..operation_desc + 204],
                &(ti + 1).to_le_bytes()
            );
            assert_eq!(
                &streaming[operation_desc + 220..operation_desc + 222],
                &(ti + 2).to_le_bytes()
            );
            assert!(!output_valid(
                &streaming[working.output + member * 1024..working.output + (member + 1) * 1024]
            ));
        }
        let mut registry = HmxQ2WeightRegistry::new(4608)?;
        let h0 = registry.prepare(&weights)?.ok_or(Error::Contract)?;
        let h1 = registry.prepare(&weights)?.ok_or(Error::Contract)?;
        let h2 = registry.prepare(&weights)?.ok_or(Error::Contract)?;
        let h3 = registry.prepare(&weights)?.ok_or(Error::Contract)?;
        let mut resident = vec![0xa5; working.allocation + 8192];
        for member in 0..4 {
            let start = working.allocation + member * 1152;
            resident[start..start + 1152].copy_from_slice(&weights);
        }
        let arena_snapshot = resident[working.allocation..].to_vec();
        // Simulate DSP pointer rewrites in the command header before regenerating.
        resident[24..696].fill(0xff);
        image_batch_resident::<4, 2048>(
            &mut resident,
            0x1234_5600,
            7,
            working.allocation,
            [&h0, &h1, &h2, &h3],
            activation_refs,
        )?;
        assert_eq!(&resident[working.allocation..], &arena_snapshot);
        for member in 0..4 {
            let w_desc = 24 + member * 3 * 56;
            let expected = working.allocation + member * 1152;
            assert_eq!(
                &resident[w_desc..w_desc + 8],
                &u64::try_from(expected)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
        }
        Ok(())
    }

    #[test]
    #[expect(
        clippy::too_many_lines,
        reason = "Keep both streaming and resident batch-ten frame layout checks together"
    )]
    fn batch10_frame_builds_thirty_tensors_ten_ops_and_preserves_resident_arena()
    -> Result<(), Error> {
        assert_eq!(HMX_Q2_BATCH10_OPERATIONS, 10);
        assert_eq!(HMX_Q2_BATCH10_COMMAND_BYTES, 4504);
        assert!(
            HmxQ2ProjectionLimits::new(32, 9, Duration::from_secs(4))?
                .with_batch_ten()
                .is_err()
        );
        assert!(
            HmxQ2ProjectionLimits::new(32, 40, Duration::from_secs(4))?
                .with_batch_four()?
                .with_batch_ten()
                .is_err()
        );
        let full =
            HmxQ2ProjectionLimits::new(17_408, 40, Duration::from_secs(20))?.with_batch_ten()?;
        assert_eq!(full.batch_operations(), 10);
        assert_eq!(full.allocation_bytes(), 11_886_592);
        assert_eq!(
            full.with_resident_weights(25_067_520)?.allocation_bytes(),
            36_954_112
        );
        assert_eq!(
            full.with_resident_weights(2 * 25_067_520)?
                .allocation_bytes(),
            62_021_632
        );
        let mut weights = vec![0x55; 1152];
        for tile in weights.as_chunks_mut::<576>().0 {
            for scale in tile[512..].as_chunks_mut::<2>().0 {
                *scale = [0, 0x3c];
            }
        }
        let activations: [[[f32; 128]; 8]; 10] = std::array::from_fn(|member| {
            let mut planes = [[0.0_f32; 128]; 8];
            planes[member % 8][member / 8] = 1.0;
            planes
        });
        let activation_refs: [&[[f32; 128]; 8]; 10] =
            std::array::from_fn(|member| &activations[member]);
        assert_eq!(
            validate_batch_inputs::<10>(32, [&weights; 10], activation_refs, [256; 10])?,
            32
        );
        let working = batch10_layout(32);
        let mut streaming = vec![0xa5; working.allocation];
        image_batch::<10, 8192>(
            &mut streaming,
            0x1234_5600,
            7,
            32,
            [&weights; 10],
            activation_refs,
        )?;
        assert_eq!(&streaming[4024..8192], &[0; 4168]);
        for member in 0..10 {
            let weight_desc = 24 + member * 3 * 56;
            let act_desc = weight_desc + 56;
            let out_desc = act_desc + 56;
            let operation_desc = 1704 + member * 232;
            let ti = u16::try_from(member * 3).map_err(|_| Error::Contract)?;
            assert_eq!(
                &streaming[weight_desc..weight_desc + 8],
                &u64::try_from(8192 + member * 1152)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
            assert_eq!(
                &streaming[weight_desc + 22..weight_desc + 24],
                &ti.to_le_bytes()
            );
            assert_eq!(
                &streaming[act_desc..act_desc + 8],
                &u64::try_from(working.activation + member * 4096)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
            assert_eq!(
                &streaming[act_desc + 22..act_desc + 24],
                &(ti + 1).to_le_bytes()
            );
            assert_eq!(
                &streaming[out_desc..out_desc + 8],
                &u64::try_from(working.output + member * 1024)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
            assert_eq!(
                &streaming[out_desc + 22..out_desc + 24],
                &(ti + 2).to_le_bytes()
            );
            assert_eq!(
                &streaming[operation_desc + 200..operation_desc + 202],
                &ti.to_le_bytes()
            );
            assert_eq!(
                &streaming[operation_desc + 202..operation_desc + 204],
                &(ti + 1).to_le_bytes()
            );
            assert_eq!(
                &streaming[operation_desc + 220..operation_desc + 222],
                &(ti + 2).to_le_bytes()
            );
            assert!(!output_valid(
                &streaming[working.output + member * 1024..working.output + (member + 1) * 1024]
            ));
        }
        let mut registry = HmxQ2WeightRegistry::new(10 * 1152)?;
        let mut handles = Vec::new();
        for _ in 0..10 {
            handles.push(registry.prepare(&weights)?.ok_or(Error::Contract)?);
        }
        let handle_refs: [&HmxQ2WeightHandle; 10] = std::array::from_fn(|member| &handles[member]);
        let mut resident = vec![0xa5; working.allocation + 12_288];
        for member in 0..10 {
            let start = working.allocation + member * 1152;
            resident[start..start + 1152].copy_from_slice(&weights);
        }
        let arena_snapshot = resident[working.allocation..].to_vec();
        resident[24..1704].fill(0xff);
        image_batch_resident::<10, 8192>(
            &mut resident,
            0x1234_5600,
            7,
            working.allocation,
            handle_refs,
            activation_refs,
        )?;
        assert_eq!(&resident[working.allocation..], &arena_snapshot);
        for member in 0..10 {
            let w_desc = 24 + member * 3 * 56;
            let expected = working.allocation + member * 1152;
            assert_eq!(
                &resident[w_desc..w_desc + 8],
                &u64::try_from(expected)
                    .map_err(|_| Error::Contract)?
                    .to_le_bytes()
            );
        }
        Ok(())
    }
}
