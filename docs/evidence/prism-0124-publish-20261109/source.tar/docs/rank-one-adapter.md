# Rank-one adapter correctness path

The source graph implements an explicit rank-one F32 adapter path for numerical
qualification. The private HTTP server now admits the exact approved adapter
only through an explicit selection; the Swift JSONL worker and ordinary token
driver retain their adapter-free subset. This source support is not a qualified
Runner default, a released-runtime claim or evidence of adapter effectiveness.

`model::lora::RankOneAdapter::load_swift` verifies the approved Orca file's exact
9,682,464-byte length and SHA-256
`f1669534803d340a496015f5c45125f3437b4d13ec764f40e34488ce83967f42`.
It requires the original pinned Swift PQ2 base and all 129 rank-one pairs with
alpha one. `load_swift_representation` admits the exact current-weight PTQ1
export only when explicitly selected; its base SHA-256 must match the selected
representation. Both APIs verify the same approved adapter bytes and preserve
the same factor and basis checks. The older publisher PTQ1 checkpoint rejects.
The general
`RankOneAdapter::from_model` constructor admits a bounded explicit subset after
checking metadata, complete F32 factor pairs, finite payloads and matching base
shapes; callers of that constructor own artifact authenticity.

Only `token_embd.weight`, `blk.N.attn_output.weight`, `blk.N.ssm_out.weight` and
`blk.N.ffn_down.weight` are admitted. `Qwen35::with_rank_one_adapter` checks that
every target is in the live graph. It seals the exact adapter identity and scale
bits into the graph identity. Scale must be finite within 0..2. The narrow
`reset_with_adapter_scale` operation clears complete state and renews checkpoint
provenance before changing scale, while retaining immutable weights and factors.
No state computed under another correction can be reused. The
[session contract](swift-session-profiles.md) defines request ownership and recovery.

An embedding adapter requires a separate `output.weight`. Graphs whose output
head reuses `token_embd.weight` reject embedding adapters at every scale,
including zero: the embedding lookup factors do not implement a tied output
projection. Such graphs can still admit supported residual-writer adapters.
Both pinned current-weight Swift representations have a separate output head.

The [pinned native graph](https://github.com/PrismML-Eng/llama.cpp/blob/73bfe6cc485554822f80c473a3c0c4f25e80f41b/src/llama-graph.cpp)
defines the operation stages: base projection, independent A/B products on the
original activation, scale, then add. Folded base Hadamard and grouped SSM
permutations stay on the base branch. Embedding corrections follow inverse
embedding transformation. The implementation retains each F32 rounding stage,
uses the existing pinned Swift accumulation contract for aligned factor rows
and bypasses correction arithmetic entirely at either signed zero scale.

The loader shares identical immutable B payloads only after kind, shape and
bytes match. Correction scratch is separate from base projection scratch and
reuses one rank value and one output-width vector. No dense vocabulary-sized
correction is constructed. These storage properties do not establish process
peak RAM, a lower admission budget or a speed improvement.

One-column F32 projections stream each B scalar directly from its immutable
payload after one geometry check. They retain the existing scalar dot's F32
product and binary64 reduction, including signed zero, and reject nonfinite
weights and products before publishing output. This removes decoded-row
validation and scratch preparation for every B output channel (660,480 across
the approved Swift adapter per token), without a second factor copy. Focused
bitwise controls compare the previous decoded-row route, including subnormals,
signed zero, product overflow and recovery. Whole-model speed and parity remain
separate qualification gates.

## Capture actual-model correctness evidence

Build the `swift_model_check` example through the external working-directory and
pinned compiler convention in [building and validation](build-and-validation.md).
From a new external native working directory, use the absolute executable path:

```powershell
& $qualifier --rank-one-adapter $approvedAdapter 0 forward $originalPq2 $zeroEvidence scalar '248045'
& $qualifier --rank-one-adapter $approvedAdapter 1.3 forward $originalPq2 $nonzeroEvidence scalar '248045'
& $qualifier --rank-one-adapter $approvedAdapter 1.3 trajectory $originalPq2 $trajectoryEvidence auto $promptIds 16
& $qualifier --use-repacked-ptq1 --rank-one-adapter $approvedAdapter 0 forward $currentPtq1 $ptq1ZeroEvidence scalar '248045'
& $qualifier --use-repacked-ptq1 --rank-one-adapter $approvedAdapter 1.3 forward $currentPtq1 $ptq1NonzeroEvidence neon '248045'
```

Every path variable must contain an expanded absolute path; evidence directories must already exist
and be distinct. The adapter must be the exact approved file. `load` also accepts the prefix;
`inspect`, relative adapter paths, unresolved environment tokens and invalid scales reject. The
example remains a source correctness tool and is not added to release bundles or ordinary service
launch. It reports the selected representation/base hash, adapter hash, target count and scale bits
and retains existing create-new logits, complete logical KV/recurrent/convolution snapshots, raw
greedy IDs and evidence-byte bounds. It produces no timing or benchmark verdict. No full-model
adapter capture was performed as part of the implementation.

Before adapter qualification, compare the same approved artifacts against pinned
native execution at loaded scale zero and intended nonzero scales. Establish
residual-writer inputs/corrections, especially grouped SSM authoring order;
complete logits and live state must retain the existing
`1e-3 + 1e-3 * abs(reference)` bound. Synthetic tests prove that this Rust branch
uses original input order; they cannot establish the publisher's authoring basis.
Final logits/state captures alone do not replace native writer-level evidence.

The explicit [private service](../server/README.md) binds adapter and representation
readiness and preserves exact count/generation scale policy. Review its immutable
release independently and qualify scale changes, cancellation, reset, streaming and
rollback on the actual target. Then run full-context/long-output, resource, same-engine
TPS and independent human quality gates on the actual target before promoting
Runner's adapter-enabled default. All benchmarks and complete suites remain
main-only CI work; focused synthetic tests and builds may run locally.

## Focused regressions

`rank_one_` tests cover malformed factors/metadata/base identities, finite scale
bounds, both signed zero bypasses, separately rounded products and addition,
post-inverse embedding correction, unrotated attention/recurrent writers,
untiled grouped SSM input order, and checkpoint/request rollback. They use small
synthetic graphs and make no full-model or native-adapter qualification claim.
